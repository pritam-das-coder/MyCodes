#  Create a tuple of string, float no’s and find length of it. 
my_tuple=('India','Brazil',3.5,8.9,'Sri Lanka',22.4501)
print(f"Tuple Created : {my_tuple}")
len=0
for i in my_tuple:
    len+=1
print(f"Length of tuple : {len}")
# Tuple Created : ('India', 'Brazil', 3.5, 8.9, 'Sri Lanka', 22.4501)
# Length of tuple : 6