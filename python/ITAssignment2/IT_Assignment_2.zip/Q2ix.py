# Show all types of slicing operation in list.
st="Pritam Das"
print(f"Original String : {st}")
print(f"String after 1st slicing operation : {st[2:5]}")
print(f"String after 2nd slicing operation : {st[:5]}")
print(f"String after 3rd slicing operation : {st[2:]}")
print(f"String after 4th slicing operation : {st[:]}")

