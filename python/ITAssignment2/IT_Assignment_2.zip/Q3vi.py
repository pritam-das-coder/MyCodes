# Perform manipulation of repetition of a string 5 times using tuples.
st="Pritam"
print(f"Original String : {st}")
tup=(st,)
new_tup=tup*5
print(f"Tuple created : {new_tup}")
# Original String : Pritam
# Tuple created : ('Pritam', 'Pritam', 'Pritam', 'Pritam', 'Pritam')