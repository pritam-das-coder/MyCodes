# To generate multiplication table using python.
n=int(input("Enter a number : "))
for i in range(1,11):
    print(n,'*',i,'=',n*i)