# Find Cube of a no using function.
def cube(num):
    return num**3
n=int(input('Enter a number : '))
print('Cube of',n,'is',cube(n))