# Perform string slicing operation.
# string slicing
str='Pritam Das'
print('Original string :',str)
print('1st operation :',str[4:9]) # 4 to 8 is sliced
print('2nd operation :',str[2:]) # 2 to end is sliced
print('3rd operation :',str[:6]) # start to 5 is sliced
print('4th operation :',str[:]) # full string
print('5th operation :',str[-6:-2]) # -6 to -3 is sliced
print('6th operation :',str[-9:8]) # -9 to 7 is sliced